from src.FootballApp import FootballApp
import sys

football_app = FootballApp()
football_app.main(sys.argv)
